﻿
public interface GestureListener {
	void OnComplete(DynGesture gesture);

	void OnRecomplete(DynGesture gesture);

	void OnRelease(DynGesture gesture);
}
